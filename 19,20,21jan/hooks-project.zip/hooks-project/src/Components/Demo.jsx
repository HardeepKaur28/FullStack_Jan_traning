import React from 'react'

const Demo = () => {
    let a = 5
    console.log(a,"dsfsd")
    // let i = 0;
    // try{
      
    //     while(true){
    //         let key = `key${i}`
    //         let value = new Array(1024).join("a")
    //         console.log(key,"runs this times")
    //         localStorage.setItem(key, JSON.stringify(value))
    //         i++;
    
    //     }
    // }
    // catch(err){
    //     console.log("localstorege storage is full", err)
    // }

  return (
    <div>
      rfsdfdsfds
    </div>
  )
}

export default Demo
